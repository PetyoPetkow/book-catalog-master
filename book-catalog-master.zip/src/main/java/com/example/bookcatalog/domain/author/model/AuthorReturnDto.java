package com.example.bookcatalog.domain.author.model;
public record AuthorReturnDto(
        Long id,

        String firstName,

        String lastName
) {
}
