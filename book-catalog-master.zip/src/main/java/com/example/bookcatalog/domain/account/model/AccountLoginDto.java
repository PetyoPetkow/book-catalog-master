package com.example.bookcatalog.domain.account.model;

public record AccountLoginDto(
        String email,

        String password
) {
}
