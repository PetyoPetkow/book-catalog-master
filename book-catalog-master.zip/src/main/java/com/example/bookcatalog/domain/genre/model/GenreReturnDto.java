package com.example.bookcatalog.domain.genre.model;

public record GenreReturnDto(
        Long id,

        String name,

        String description
) {
}
