package com.example.bookcatalog.domain.account.model;

public record AccountReturnDto(
        Long id,

        String email,

        String username
) {
}
