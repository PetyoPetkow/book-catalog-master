package com.example.bookcatalog.infrastructure.exception;

public class SearchParamParseException extends RuntimeException{
    public SearchParamParseException(String message) {
        super(message);
    }
}
