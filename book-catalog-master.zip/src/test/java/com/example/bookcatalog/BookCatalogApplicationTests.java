package com.example.bookcatalog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookCatalogApplicationTests {

    @Test
    void contextLoads() {
    }

}
